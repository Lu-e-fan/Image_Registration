import numpy as np
import cv2 as cv
#only libraries we used are opencv 3.4.2
#numpy 1.16.5

#feature matching code taken from opencv example https://docs.opencv.org/3.4/dc/dc3/tutorial_py_matcher.html
def featureMatching(img1,img2):
    sift = cv.xfeatures2d.SIFT_create()
    kp1, des1 = sift.detectAndCompute(img1,None)
    kp2, des2 = sift.detectAndCompute(img2,None)
    bf = cv.BFMatcher()
    matches = bf.knnMatch(des1,des2,k=2)
    
    good = []
    for m,n in matches:
        if m.distance < 0.75*n.distance:
            good.append(m)
            
    if len(good)>10:
        src_pts = np.float32([ kp1[m.queryIdx].pt for m in good ]).reshape(-1,1,2)
        dst_pts = np.float32([ kp2[m.trainIdx].pt for m in good ]).reshape(-1,1,2)      
    
    return([src_pts,dst_pts])

def DLT_Standard(p1,p2):
    A = []
    for i in range(0, len(p1)):
        x, y = p1[i][0][0], p1[i][0][1]
        u, v = p2[i][0][0], p2[i][0][1]
        A.append([x, y, 1, 0, 0, 0, -u*x, -u*y, -u])
        A.append([0, 0, 0, x, y, 1, -v*x, -v*y, -v])
    A = np.asarray(A)
    U, S, Vh = np.linalg.svd(A)
    L = Vh[-1,:] / Vh[-1,-1]
    H = L.reshape(3, 3)
    return H


def DLT_Normalized(p1,p2):
    A = []
    sum_x = 0
    sum_y = 0
    sum_u = 0
    sum_v = 0
    sum_xyk=0
    sum_uvk=0
    for i in range(0, len(p1)):
        x, y = p1[i,0,0], p1[i,0,1]
        u, v = p2[i,0,0], p2[i,0,1]
        sum_x = sum_x + x
        sum_y = sum_y + y
        sum_u = sum_u + u 
        sum_v = sum_v + v  
    X_C = sum_x/len(p1)
    Y_C = sum_y/len(p1)
    U_C = sum_u/len(p1)
    V_C = sum_v/len(p1)
    for k in range(0,len(p1)):
        sum_xyk= sum_xyk + np.sqrt( (p1[k,0,0]-X_C)**2 + (p1[k,0,1]-Y_C)**2 )
        sum_uvk= sum_uvk + np.sqrt( (p2[k,0,0]-U_C)**2 + (p2[k,0,1]-V_C)**2 )
    dav_xy = sum_xyk/len(p1)
    dav_uv = sum_uvk/len(p1)
    for j in range(0,len(p1)):
        x_, y_ = (np.sqrt(2)/dav_xy)*(p1[j,0,0]-X_C),(np.sqrt(2)/dav_xy)*(p1[j,0,1]-Y_C)
        u_, v_ = (np.sqrt(2)/dav_uv)*(p2[j,0,0]-U_C),(np.sqrt(2)/dav_uv)*(p2[j,0,1]-V_C)
        A.append([x_, y_, 1, 0, 0, 0, -u_*x_, -u_*y_, -u_])
        A.append([0, 0, 0, x_, y_, 1, -v_*x_, -v_*y_, -v_])       

    A = np.asarray(A)
    U, S, Vh = np.linalg.svd(A)
    L = Vh[-1,:] / Vh[-1,-1]
    H = L.reshape(3, 3)
    return H

def registerImage(img1,img2,H):
    h1,w1,c=img1.shape
    h2,w2,c=img2.shape
    
    box2 = np.float32([ [0,0], [0,h1], [w1, h1], [w1,0] ]).reshape(-1,1,2)
    box1_temp = np.float32([ [0,0], [0,h2], [w2, h2], [w2,0] ]).reshape(-1,1,2)
    box1 = cv.perspectiveTransform(box1_temp, H)
    
    t = np.array([[1,0,-np.amin(box1[:,0,0])],[0,1,-np.amin(box1[:,0,1])],[0,0,1]])
    imReg = cv.warpPerspective(img1, np.matmul(t,H), (np.amax(box1[:,0,0])-np.amin(box1[:,0,0]), np.amax(box1[:,0,1])-np.amin(box1[:,0,1])))
    left = min(box2[0,0,0],box1[0,0,0],box1[1,0,0])
    right = max(box2[3,0,0],box1[3,0,0],box1[2,0,0])
    top = min(box2[0,0,1],box1[0,0,1],box1[3,0,1])
    bottom = max(box2[1,0,1],box1[1,0,1],box1[2,0,1])
    width = int(right - left)
    height = int(bottom-top)
    img = np.zeros((height,width,3))
    
    pt1,pt2 = featureMatching(cv.cvtColor(imReg,cv.COLOR_BGR2GRAY),cv.cvtColor(img2,cv.COLOR_BGR2GRAY))
    H1,mask = cv.findHomography(pt1,pt2,cv.RANSAC)
    tx = int(H1[0,2])
    ty = int(H1[1,2])
    img = np.zeros((int(height*1.2),int(width*1.2),3))
    imReg_padded = np.zeros((img.shape))
    img2_padded = np.zeros((img.shape))
    if tx > 0 and ty < 0:
        h,w,c = imReg.shape    
        imReg_padded[0:h,tx:tx+w,:] = imReg   
        img2_padded[-ty:-ty+h2,0:w2,:] = img2
    if tx < 0 and ty < 0:
        h,w,c = imReg.shape
        imReg_padded[0:h,0:w,:] = imReg
        img2_padded[-ty:-ty+h2,-tx:-tx+w2,:] = img2
    if tx > 0 and ty > 0:
        h,w,c = imReg.shape
        imReg_padded[ty:ty+h,tx:tx+w,:] = imReg
        img2_padded[0:h2,0:w2,:] = img2
    if tx < 0 and ty > 0:
        h,w,c = imReg.shape
        imReg_padded[ty:ty+h,0:w,:] = imReg
    
    for i in range(height):
        for j in range(width):
            img[i,j,:] = .5*imReg_padded[i,j,:] + .5*img2_padded[i,j,:]
    return img

if __name__ == "__main__":
    
    img1 = cv.imread('overhead_1.jpg')
    img2 = cv.imread('overhead_2.jpg')
    gray1 = cv.cvtColor(img1,cv.COLOR_BGR2GRAY)
    gray2 = cv.cvtColor(img2,cv.COLOR_BGR2GRAY)
    points1, points2 = featureMatching(gray1,gray2)
    H1 = DLT_Standard(points1,points2)
    H2N = DLT_Normalized(points1,points2)
    H2, m = cv.findHomography(points1, points2, 0)
    H3, mask = cv.findHomography(points1, points2, cv.RANSAC)
    height, width, channels = img2.shape
    im1Reg_1 = cv.warpPerspective(img1, H1, (width, height)) 
    cv.imwrite("OH_DLT.jpg", im1Reg_1)
    im1Reg_2 = cv.warpPerspective(img1, H2, (width, height)) 
    cv.imwrite("OH_DLT_N.jpg", im1Reg_2)
    im1Reg_3 = cv.warpPerspective(img1, H3, (width, height)) 
    cv.imwrite("OH_RAN.jpg", im1Reg_3)
#     im1 = registerImage(img1,img2,H1)
#     im2 = registerImage(img1,img2,H2)
#     im3 = registerImage(img1,img2,H3)
#     cv.imwrite("StandardDLT.jpg",im1)
#     cv.imwrite("NormDLT.jpg",im2)
#     cv.imwrite("RANSACDLT.jpg",im3)


